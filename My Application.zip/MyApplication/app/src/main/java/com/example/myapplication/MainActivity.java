package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    private Button button ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = (Button) findViewById(R.id.main_login_btn);
        button.setOnClickListener(new View.OnClickListener()


        {
            @Override
            public void onClick(View v)
            {
              Intent intent = new Intent(MainActivity.this,activity_login.class);
              startActivity( intent);
            }





        });
        button = (Button) findViewById(R.id.join_now_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity_registration.class);
                startActivity(intent);
            }
        });

        button = (Button) findViewById(R.id.skip_btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity_brand.class);
                startActivity(intent);
            }
        });

    }
}