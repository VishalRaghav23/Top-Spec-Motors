package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class activity_brand extends AppCompatActivity
{

 private ImageView imageView ;

 @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brand);



        imageView = (ImageView) findViewById(R.id.ms);
        imageView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(activity_brand.this, activity_ms.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.honda);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, activity_honda.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.hyundai);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, activity_hyundai.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.honda);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, activity_honda.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.tata);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, activity_tata.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.kia);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, activity_kia.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.datsun);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, datsun.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.mini);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_brand.this, mini.class);
                startActivity(intent);
            }
        });




    }
}

