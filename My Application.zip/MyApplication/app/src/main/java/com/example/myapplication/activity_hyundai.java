package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class activity_hyundai extends AppCompatActivity {
    CardView hyundai_verna;
    CardView hyundai_venue;
    CardView hyundai_creta;
    CardView hyundai_i10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hyundai);

        hyundai_verna = findViewById(R.id.hyundai_verna);
        hyundai_verna.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_hyundai.this, hyundai_verna.class);
                startActivity(intent);
            }
        });
        hyundai_venue = findViewById(R.id.hyundai_venue);
        hyundai_venue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_hyundai.this, hyundai_venue.class);
                startActivity(intent);
            }
        });
        hyundai_creta = findViewById(R.id.hyundai_creta);
        hyundai_creta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_hyundai.this, hyundai_creta.class);
                startActivity(intent);
            }
        });
        hyundai_i10 = findViewById(R.id.hyundai_i10);
        hyundai_i10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_hyundai.this, hyundai_i10.class);
                startActivity(intent);
            }
        });




    }
}
