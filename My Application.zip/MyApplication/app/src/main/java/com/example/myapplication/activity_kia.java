package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class activity_kia extends AppCompatActivity {
CardView kia_seltos;
CardView kia_carnival;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kia);

        kia_seltos = findViewById(R.id.kia_seltos);
        kia_seltos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_kia.this, kia_seltos.class);
                startActivity(intent);
            }
        });
        kia_carnival = findViewById(R.id.kia_carnival);
        kia_carnival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_kia.this, kia_carnival.class);
                startActivity(intent);
            }
        });


    }
}
