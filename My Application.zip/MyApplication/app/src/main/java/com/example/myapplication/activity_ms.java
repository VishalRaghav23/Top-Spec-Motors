package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class activity_ms extends AppCompatActivity
{
    private TextView textView;
    private ImageView imageView ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ms);

        textView= (TextView) findViewById(R.id.ms_Baleno_btn);
        textView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(activity_ms.this,activity_baleno.class);
                startActivity(intent);
            }
        });
        textView = (TextView) findViewById(R.id.brezza_btn);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_brezza.class);
                startActivity(intent);
            }
        });
        textView= (TextView) findViewById(R.id.ciaz_btn);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_brezza.class);
                startActivity(intent);
            }
        });
        textView = (TextView) findViewById(R.id.ms_xl6_btn);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_xl6.class);
                startActivity(intent);
            }
        });
        textView = (TextView) findViewById(R.id.ms_wagon_btn);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, activity_baleno.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.ms_Baleno);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, activity_baleno.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.ms_Brezza);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_brezza.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.ms_Ciaz);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_ciaz.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.ms_xl6);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_xl6.class);
                startActivity(intent);
            }
        });
        imageView = (ImageView) findViewById(R.id.ms_wagon);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_ms.this, ms_xl6.class);
                startActivity(intent);
            }
        });




    }
}
