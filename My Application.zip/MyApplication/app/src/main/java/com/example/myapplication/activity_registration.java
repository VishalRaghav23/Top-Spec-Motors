package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class activity_registration extends AppCompatActivity {
    private Button createAccountButton;
    private EditText InputName, InputNumber,InputPassword, InputConfirmPassword;
    private ProgressDialog loadingbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        createAccountButton = (Button) findViewById(R.id.Create_btn);
        InputName = (EditText) findViewById(R.id.Enter_name);
        InputNumber = (EditText) findViewById(R.id.phone_number);
        InputPassword = (EditText) findViewById(R.id.enter_password);
        InputConfirmPassword = (EditText) findViewById(R.id.again_password);
        loadingbar = new ProgressDialog(this);

     createAccountButton.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v)
         {
          createAccount();
         }
     });

    }

    private void createAccount()
    {
        String name = InputName.getText().toString();
        String number = InputNumber.getText().toString();
        String password = InputPassword.getText().toString();
        String confirm = InputConfirmPassword.getText().toString();
        if (TextUtils.isEmpty(name))
        {
            Toast.makeText(this,"Please Enter Your Name",Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(number))
        {
            Toast.makeText(this,"Please Enter Your Number",Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(password))
        {
        Toast.makeText(this,"Please Enter Your Password",Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(confirm))
        {
            Toast.makeText(this,"Please Enter Your Password",Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingbar.setTitle("Create Account");
            loadingbar.setMessage("Please wait, while we are checking the credentails");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();

        }
    }
}
