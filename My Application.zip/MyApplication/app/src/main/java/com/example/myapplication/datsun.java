package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class datsun extends AppCompatActivity {
    CardView datsun_redi;
    CardView datsun_go;
    CardView datsun_goplus;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datsun);

        datsun_redi = findViewById(R.id.datsun_redi);
        datsun_redi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(datsun.this, datsun_redi.class);
                startActivity(intent);
            }
        });

        datsun_goplus = findViewById(R.id.datsun_goplus);
        datsun_goplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(datsun.this, datsun_goplus.class);
                startActivity(intent);
            }
        });
        datsun_go = findViewById(R.id.datsun_go);
        datsun_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(datsun.this, datsun_go.class);
                startActivity(intent);
            }
        });




    }
}
