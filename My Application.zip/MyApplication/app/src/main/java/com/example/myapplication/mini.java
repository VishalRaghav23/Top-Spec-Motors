package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class mini extends AppCompatActivity {
    CardView mini_cooper;
    CardView mini_coopercon;
    CardView mini_countryman;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mini);

        mini_cooper = findViewById(R.id.mini_cooper);
        mini_cooper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mini.this, mini_cooper.class);
                startActivity(intent);
            }
        });
        mini_coopercon = findViewById(R.id.mini_coopercon);
        mini_coopercon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mini.this, mini_coopercon.class);
                startActivity(intent);
            }
        });
        mini_countryman = findViewById(R.id.mini_countryman);
        mini_countryman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mini.this, mini_countryman.class);
                startActivity(intent);
            }
        });
    }

}
